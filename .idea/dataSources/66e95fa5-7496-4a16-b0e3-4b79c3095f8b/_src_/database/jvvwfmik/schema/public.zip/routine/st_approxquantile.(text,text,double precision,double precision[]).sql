CREATE FUNCTION st_approxquantile (rastertable text, rastercolumn text, sample_percent double precision, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT _st_quantile($1, $2, 1, TRUE, $3, $4) 
$$
