CREATE FUNCTION xpath_list (text, text) RETURNS text
	LANGUAGE sql
AS $$
SELECT xpath_list($1,$2,',')
$$
