CREATE FUNCTION st_count (rastertable text, rastercolumn text, exclude_nodata_value boolean) RETURNS bigint
	LANGUAGE sql
AS $$
 SELECT _st_count($1, $2, 1, $3, 1) 
$$
