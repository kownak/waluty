CREATE FUNCTION st_asgml (text) RETURNS text
	LANGUAGE sql
AS $$
 SELECT _ST_AsGML(2,$1::geometry,15,0, NULL, NULL);  
$$
