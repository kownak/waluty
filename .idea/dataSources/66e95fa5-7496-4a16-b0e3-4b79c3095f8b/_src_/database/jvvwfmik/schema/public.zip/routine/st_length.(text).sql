CREATE FUNCTION st_length (text) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT ST_Length($1::geometry);  
$$
