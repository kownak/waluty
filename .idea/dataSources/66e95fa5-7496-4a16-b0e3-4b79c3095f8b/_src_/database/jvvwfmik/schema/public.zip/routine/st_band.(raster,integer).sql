CREATE FUNCTION st_band (rast raster, nband integer) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_band($1, ARRAY[$2]) 
$$
