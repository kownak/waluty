CREATE FUNCTION st_pixelascentroid (rast raster, x integer, y integer) RETURNS geometry
	LANGUAGE sql
AS $$
 SELECT ST_Centroid(geom) FROM _st_pixelaspolygons($1, NULL, $2, $3) 
$$
