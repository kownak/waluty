CREATE FUNCTION st_aslatlontext (geometry) RETURNS text
	LANGUAGE sql
AS $$
 SELECT ST_AsLatLonText($1, '') 
$$
