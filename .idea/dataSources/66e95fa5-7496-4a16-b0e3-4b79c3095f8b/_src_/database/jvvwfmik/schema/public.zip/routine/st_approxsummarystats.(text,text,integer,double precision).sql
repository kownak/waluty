CREATE FUNCTION st_approxsummarystats (rastertable text, rastercolumn text, nband integer, sample_percent double precision, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision) RETURNS record
	LANGUAGE sql
AS $$
 SELECT _st_summarystats($1, $2, $3, TRUE, $4) 
$$
