CREATE FUNCTION st_within (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && $2 AND _ST_Contains($2,$1)
$$
