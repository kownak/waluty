CREATE FUNCTION postgis_raster_scripts_installed () RETURNS text
	LANGUAGE sql
AS $$
 SELECT '2.1.5'::text || ' r' || 13152::text AS version 
$$
