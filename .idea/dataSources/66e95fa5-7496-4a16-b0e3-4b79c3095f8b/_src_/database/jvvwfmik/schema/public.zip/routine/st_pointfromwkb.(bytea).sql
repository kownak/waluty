CREATE FUNCTION st_pointfromwkb (bytea) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'POINT'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END
	
$$
