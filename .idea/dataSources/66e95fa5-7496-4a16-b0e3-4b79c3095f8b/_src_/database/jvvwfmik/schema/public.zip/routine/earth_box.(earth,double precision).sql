CREATE FUNCTION earth_box (earth, double precision) RETURNS cube
	LANGUAGE sql
AS $$
SELECT cube_enlarge($1, gc_to_sec($2), 3)
$$
