CREATE FUNCTION earth_distance (earth, earth) RETURNS double precision
	LANGUAGE sql
AS $$
SELECT sec_to_gc(cube_distance($1, $2))
$$
