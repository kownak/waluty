CREATE FUNCTION longitude (earth) RETURNS double precision
	LANGUAGE sql
AS $$
SELECT degrees(atan2(cube_ll_coord($1, 2), cube_ll_coord($1, 1)))
$$
