CREATE FUNCTION st_quantile (rast raster, nband integer, quantile double precision) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT (_st_quantile($1, $2, TRUE, 1, ARRAY[$3]::double precision[])).value 
$$
