CREATE FUNCTION st_valuecount (rastertable text, rastercolumn text, nband integer, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT count integer) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT value, count FROM _st_valuecount($1, $2, $3, TRUE, $4, $5) 
$$
