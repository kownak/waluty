CREATE FUNCTION st_polygonfromtext (text) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT ST_PolyFromText($1)
$$
