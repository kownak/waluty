CREATE FUNCTION st_geomcollfromwkb (bytea) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE
	WHEN geometrytype(ST_GeomFromWKB($1)) = 'GEOMETRYCOLLECTION'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END
	
$$
