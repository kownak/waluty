CREATE FUNCTION st_rastertoworldcoordy (rast raster, yr integer) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT latitude FROM _st_rastertoworldcoord($1, NULL, $2) 
$$
