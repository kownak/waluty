CREATE FUNCTION xpath_nodeset (text, text, text) RETURNS text
	LANGUAGE sql
AS $$
SELECT xpath_nodeset($1,$2,'',$3)
$$
