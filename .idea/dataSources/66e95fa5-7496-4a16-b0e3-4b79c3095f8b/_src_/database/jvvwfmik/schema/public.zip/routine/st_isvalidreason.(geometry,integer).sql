CREATE FUNCTION st_isvalidreason (geometry, integer) RETURNS text
	LANGUAGE sql
AS $$
SELECT CASE WHEN valid THEN 'Valid Geometry' ELSE reason END FROM (
	SELECT (ST_isValidDetail($1, $2)).*
) foo
	
$$
