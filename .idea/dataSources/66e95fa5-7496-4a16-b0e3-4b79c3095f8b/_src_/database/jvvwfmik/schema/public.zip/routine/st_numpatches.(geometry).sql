CREATE FUNCTION st_numpatches (geometry) RETURNS integer
	LANGUAGE sql
AS $$
	SELECT CASE WHEN ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN ST_NumGeometries($1)
	ELSE NULL END
	
$$
