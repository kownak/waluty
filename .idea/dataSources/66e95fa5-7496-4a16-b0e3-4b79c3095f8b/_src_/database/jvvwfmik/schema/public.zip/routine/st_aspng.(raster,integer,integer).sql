CREATE FUNCTION st_aspng (rast raster, nband integer, compression integer) RETURNS bytea
	LANGUAGE sql
AS $$
 SELECT st_aspng($1, ARRAY[$2], $3) 
$$
