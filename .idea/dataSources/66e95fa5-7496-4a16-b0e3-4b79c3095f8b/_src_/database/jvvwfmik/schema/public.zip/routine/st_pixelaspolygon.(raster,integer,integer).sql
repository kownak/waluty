CREATE FUNCTION st_pixelaspolygon (rast raster, x integer, y integer) RETURNS geometry
	LANGUAGE sql
AS $$
 SELECT geom FROM _st_pixelaspolygons($1, NULL, $2, $3) 
$$
