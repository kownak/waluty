CREATE FUNCTION st_mapalgebrafct (rast raster, band integer, pixeltype text, onerastuserfunc regprocedure) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_mapalgebrafct($1, $2, $3, $4, NULL) 
$$
